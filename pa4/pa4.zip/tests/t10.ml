let f = function (x) { function (y) { (x + y) }} in
let g = (f 10) in
(g 100)
