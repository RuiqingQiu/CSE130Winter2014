let l = [1;2;3;4] in
let m = [5;6;7;8] in
((hd l) :: (tl m))
