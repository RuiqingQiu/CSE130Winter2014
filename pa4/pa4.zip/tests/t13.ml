let f = function (x) { function (y) { function (a) { (a (x*y)) }}} in
let g = function (x) { (x+(1*3)) } in
(((f 7) 8) g)
