
type binary_operator = 
  | Plus
  | Minus
  | Mul
  | Div
  | Eq
  | Ne
  | Lt
  | Le
  | And
  | Or

type expr =   
  | Int of int
  | Bool of bool
  | Var of string
  | BinaryOp of expr * binary_operator * expr
  | Let of string * expr * expr
  | If of expr * expr * expr
  | Fun of string * expr
  | App of expr * expr

let indent k = failwith "to be written"

let strBinOp : binary_operator -> string =
function
  | Plus -> "+"
  | Minus -> "-"
  | Mul -> "*"
  | Div -> "/"
  | Eq -> "="
  | Ne -> "<>"
  | Lt -> "<"
  | Le -> "<="
  | And -> "&&"
  | Or -> "||"

let rec strExpr depth e =
  match e with
    | _ ->
       failwith "to be written"

let printExpr e =
  let s = strExpr 0 e in
  let _ = Printf.printf "%s\n" s in
  String.length s

